document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.getElementById("contenedor-productos-dummy");
  const titulo = document.createElement("h1");
  titulo.textContent = "DummyJson API";

  contenedor.appendChild(titulo);

  // Categorias posibles:
  // smartphones
  // laptops
  // fragrances
  // groceries
  // home-decoration
  // furniture
  // tops
  // womens-dresses
  // womens-shoes
  // mens-shirts
  // mens-shoes
  // mens-watches
  // womens-watches
  // womens-bags
  // womens-jewellery
  // sunglasses
  // motorcycle
  //beauty

  let categoria = "beauty";

  let urlCategoria = `https://dummyjson.com/products/category/${categoria}`;
  let url = "https://dummyjson.com/products";

  if (categoria) {
    const tituloCategoria = document.createElement("h2");
    tituloCategoria.textContent = `Categoria: ${categoria}`;

    contenedor.appendChild(tituloCategoria);
  }

  //Eligen si pedir todo o filtrar por categoria
  fetch(urlCategoria)
    .then((response) => response.json())
    .then((data) =>
      data.products.forEach((prod) => {
        const tarjeta = document.createElement("article");
        const titulo = document.createElement("h1");
        const precio = document.createElement("p");
        const imagen = document.createElement("img");
        const boton = document.createElement("button");

        titulo.textContent = prod.title;
        precio.textContent = `$${prod.price}`;
        imagen.src = prod.images[0];
        boton.textContent = "Agregar al carrito";

        tarjeta.append(imagen, titulo, precio, boton);

        contenedor.appendChild(tarjeta);
      }),
    );
});
